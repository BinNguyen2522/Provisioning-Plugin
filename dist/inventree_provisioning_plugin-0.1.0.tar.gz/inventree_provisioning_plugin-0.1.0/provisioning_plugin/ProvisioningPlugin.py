from plugin import InvenTreePlugin
from plugin.mixins import AppMixin, SettingsMixin
from .version import PROVISIONING_PLUGIN_VERSION


class ProvisioningPlugin(AppMixin, SettingsMixin, InvenTreePlugin):
    NAME = "ProvisioningPlugin"
    SLUG = "provisioning"  # Sẽ tạo ra URL dạng /plugin/provisioning/
    TITLE = "Provisioning Plugin"
    AUTHOR = "Your Name"
    DESCRIPTION = "Adds provisioning status, IMEI to Parts and a provisioning log."
    VERSION = PROVISIONING_PLUGIN_VERSION
    MIN_VERSION = "0.13.0"  # Phiên bản InvenTree tối thiểu plugin này hỗ trợ

    # Không có settings cụ thể trong yêu cầu, nhưng vẫn giữ mixin nếu cần sau này
    # SETTINGS = {
    #     'SOME_SETTING': {
    #         'name': 'Some Setting',
    #         'description': 'A description for this setting',
    #         'default': True,
    #         'validator': bool,
    #     }
    # }